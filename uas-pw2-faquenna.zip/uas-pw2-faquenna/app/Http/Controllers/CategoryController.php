<?php

namespace App\Http\Controllers;
use App\Models\CategoryModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    function index()
    {
        $data= array( 
            'categories.index' => CategoryModel::all()
        );
        return view('categories.list', $data);
    }
}