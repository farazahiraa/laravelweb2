<?php

namespace App\Http\Controllers;

use App\Models\CategoryModel;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $data = [
            'categories' => CategoryModel::all()
        ];
        return view('categories.index', $data);
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(Request $request)
    {
    
        $validatedData = $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:categories,email'
        ]);

        try {
            CategoryModel::create($validatedData);
            
            return redirect()->route('categories.index')
                           ->with('success', 'Data kategori berhasil disimpan');
        } catch (\Exception $e) {
            return redirect()->back()
                           ->withInput()
                           ->with('error', 'Gagal menyimpan data: '.$e->getMessage());
        }
    }
}