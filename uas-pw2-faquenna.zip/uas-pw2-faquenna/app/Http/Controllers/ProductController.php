<?php

namespace App\Http\Controllers;
use App\Models\ProductModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    function index()
    {
        $data= array(
            'product.index' => ProductModel::all()
        );
        return view('product.list', $data);
    }
}
