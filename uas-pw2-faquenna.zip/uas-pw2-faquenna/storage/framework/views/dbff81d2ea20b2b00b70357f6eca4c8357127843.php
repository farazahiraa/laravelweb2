<!DOCTYPE html>
<html>
<head>
    <title>Tambah Kategori - Faquenna Accessories</title>
</head>
<body>
    <h1>Tambah Kategori Baru</h1>

    <form action="<?php echo e(route('categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Nama Kategori:</label>
        <input type="text" name="name" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <br><br>
        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('categories.index')); ?>">← Kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\uas-pw2-faquenna\resources\views/categories/create.blade.php ENDPATH**/ ?>