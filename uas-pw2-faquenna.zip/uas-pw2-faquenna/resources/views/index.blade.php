<!DOCTYPE html>
<html>
<head>
    <title>Data Kategori - Faquenna Accessories</title>
</head>
<body>
    <h1>Daftar Kategori Aksesoris</h1>
</body>
</html>