@extends('layouts.app')

@section('title', 'List Category')

@section('content')
    <h1>Daftar Kategori</h1>
    <a href="{{ url('/category/insert') }}">Tambah Kategori</a>
    <table class="table table-bordered">
        <tr>
            <th>Nama</th>
            <th>Aksi</th>
        </tr>
        @foreach($categories as $category)
            <tr>
                <td>{{ $category->nama }}</td> {{-- Ganti 'nama' dengan field yang sesuai di database --}}
                <td>
                    <a href="{{ url('/category/update/' . $category->id) }}">Ubah</a>
                    <a href="{{ url('/category/delete/' . $category->id) }}">Hapus</a>
                </td>
            </tr>
        @endforeach
    </table>
@endsection

